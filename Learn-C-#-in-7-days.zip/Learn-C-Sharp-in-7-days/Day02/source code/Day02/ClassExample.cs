﻿using System;

namespace Day02
{
    public class ClassExample
    {
        public void Display()
        {
            Console.WriteLine("This is a class 'ClassExample' of namespace 'Day02'. ");
        }
    }
}

namespace Day02New
{

    public class ClassExample
    {
        public void Display()
        {
            Console.WriteLine("This is a class 'ClassExample' of namespace 'Day02New'. ");
        }
    }
}